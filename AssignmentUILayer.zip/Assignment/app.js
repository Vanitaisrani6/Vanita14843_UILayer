var counter=0;
var cnt1=0;
var cnt2=0;
function myFunction(elem){
    if(elem.id=='img1'){
        counter+=1;
        document.getElementById('spanId1').innerHTML=counter;
    }
    else if(elem.id =='img2'){
        cnt1+=1;
        document.getElementById('spanId2').innerHTML=cnt1;
    }
    else if(elem.id=='img3'){
        cnt2+=1;
        document.getElementById('spanId3').innerHTML=cnt2;
    }
}